=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: tags shortcode
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin adds a new shortcode which will call funtion the_tags()

== Description ==


Plugin adds a new shortcode which allows you to display all tags of current posts exaclty how function the_tags() does


== Frequently Asked Questions ==

= What happends if i add this shortcode in my content ? =

If you add this shortcode in your body, you will see in front-end a list with tags of current post.

== Screenshots ==

1. Please see in back-end shortcode functionality


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add shortcode [tags] in your content



== Changelog ==

= 1.0 =
* Add a new shortcode for display a list of tags


== Upgrade Notice ==

= 1.0 =
* Add a new shortcode for display a list of tags

