=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: posts exclude
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to exclude posts from search results

== Description ==

Plugin adds a new option in backend where you can add ids of posts that you want excluded from search results

== Frequently Asked Questions ==

= What happends if i don't add any id to exclude field? =

If you don't add any id on exlcude field the search will work normally

== Screenshots ==

1.In Screenshot you can see how you can add post ids for excluding

== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a new option in backend .


== Upgrade Notice ==

= 1.0 =
*If post ids are added they will be excluded from search 


