=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: posts list thumbnail
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin add a new column in list with thumbnail

== Description ==

Plugin adds a new column in posts list named thumbnail where you will see the image or none in case it doesn't exists

== Frequently Asked Questions ==

= What happends if i don't have any image in my post? =

If you don't have any image in your post you will see a simple text "none".

== Screenshots ==

1.In Screenshot you can see how thumbs look in backend

== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a column in edit posts lists

== Upgrade Notice ==

= 1.0 =
* Add a column in edit posts lists

