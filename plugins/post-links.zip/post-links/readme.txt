=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: popup links
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to add related links on your post content

== Description ==

Plugin adds a new metabox in post edit where tou can add multiple related link to your body-content of posts.

== Frequently Asked Questions ==

= What happends if i don't add any related link to post? =

If you don't add any link to post will not affect anything

== Screenshots ==

1.In Screenshot you can see how you can add links to post

== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a custom metabox to edit post page on backend


== Upgrade Notice ==

= 1.0 =
If metabox is completed it will show a list with links on bottom of posts


