=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: ip ban
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to ban ips

== Description ==

Plugin adds a new option in backend where you can add ips that you want to be banned and redirect to a sett url.

== Frequently Asked Questions ==

= What happends if i don't add any id to ips ban field? =

If you don't add any ip to ban notthing will happend

== Screenshots ==

1.In Screenshot you can see how you can add ips to exclude

== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a new option in backend .


== Upgrade Notice ==

= 1.0 =
*If if ips are added that users will be redirected to sett url

