=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: posts shortcode
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin adds a new shortcode which allows you to display 5 article 

== Description ==


Plugin adds a new shortcode which allows you to display last 5 article posts with links from selected category


== Frequently Asked Questions ==

= What happends if i don't add any category value? =

Default category is uncategorized so you could have no results.

== Screenshots ==

1. Please see in back-end shortcode functionality


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add shortcode [posts category="#category-slug#"] in your content



== Changelog ==

= 1.0 =
* Add a new shortcode for display a list of articles


== Upgrade Notice ==

= 1.0 =
* You can also let category field empty

