=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: dashboard widgets
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to inactivate dashboard widgets

== Description ==

Plugin adds a new options in backend where you can select which of the dashboard widgets to be inactivated


== Frequently Asked Questions ==

= What happends if i don't choose any of the dashboard widgets? =

If none dashboard widget is selected script will not affect anything

== Screenshots ==

1.In Screenshot you can see how you can choose what widget to hide.


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a new options where you can choose dashboard widgets


== Upgrade Notice ==

= 1.0 =
* We will add a new options for dashboard widgets

