=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: popup box,posts
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to add any popup info to your posts

== Description ==

Plugin adds a new metabox in post edit where tou can add popup box content for that specific post, if the popup content box is not empty it will activate one popup box on single for that post.



== Frequently Asked Questions ==

= What happends if i don't complete popup box? =

If the popup box remains empty it will not affect at all your post front-end display.

== Screenshots ==

1.In Screenshot you can see how you can content to popupbox and does it look in front-end


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add following lines where you want to display respectivelly scripts.


== Changelog ==

= 1.0 =
* Add a custom metabox to edit post page on backend


== Upgrade Notice ==

= 1.0 =
If metabox is completed it will show one popup box on post display

