=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: redirect anything
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you redirect any kind of plugin from your site .

== Description ==

Plugin adds a new options in backend where you can choose what type of url to be redirected to a specific url


== Frequently Asked Questions ==

= What happends if i don't choose one of colums ? =

If one of the colums will not be completed the save will not procede.

== Screenshots ==

1.In Screenshot you can see how you can sett multiple redirect rules.


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a new options where you can make a redirect rule


== Upgrade Notice ==

= 1.0 =
* You can also delete all redirect rules

