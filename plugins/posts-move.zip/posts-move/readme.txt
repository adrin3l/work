=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: posts, category, move
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you move all post from a category to other .

== Description ==

Plugin adds a new options in backend where you can copy posts from a category to another by one click



== Frequently Asked Questions ==

= What happends if i don't choose one of categories? =

If one of the categories is not choosed the script will not run .

== Screenshots ==

1.In Screenshot you can see how you can move posts from a category to another.


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 1.0 =
* Add a new options where you can make the movement


== Upgrade Notice ==

= 1.0 =
* We will add a new options for other taxonomies to 

