=== Plugin Name ===
Contributors: Daniel Andrei Adrian
Tags: popup box
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 1.5
License: GPLv2 or later

Plugin helps you to add a pop anywhere in you site

== Description ==

Plugin adds a new option in back-end where you can sett popup content and seconds delay until the popup closes.


== Frequently Asked Questions ==

= What happends if i don't complete popup delay field? =

If the popup box remains empty it will not close automatically.

== Screenshots ==

1.In Screenshot you can see how you can put content to popupbox 


== Installation ==

1. Upload automatic-posting to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add following lines where you want to display respectivelly scripts.

add_action('popup_box')


== Changelog ==

= 1.0 =
* Add an option to edit your popup box settings


== Upgrade Notice ==

= 1.0 =
* Popup will automatically close if you give it a value for delay

